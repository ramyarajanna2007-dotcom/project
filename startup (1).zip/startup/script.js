function generateIdea(){

let skills =
document.getElementById(
"skills").value;

let interest =
document.getElementById(
"interest").value;

document.getElementById(
"idea").innerHTML=

"AI Startup for " +
interest +
" using " +
skills;

document.getElementById(
"team").innerHTML=

"Frontend Developer<br>" +
"Backend Developer<br>" +
"AI Engineer<br>" +
"Marketing Lead";

document.getElementById(
"pitch").innerHTML=

"Problem: Students lack startup support.<br>" +

"Solution: AI platform for startup creation.<br>" +

"Target Users: Students and innovators.<br>" +

"Revenue: Subscription model";
}
function login(){

let email=

document.getElementById(
"email").value;

let password=

document.getElementById(
"password").value;

if(
email=="" ||
password==""
){

document.getElementById(
"message"
).innerHTML=

"Enter Email and Password";

}

else{

document.getElementById(
"message"
).innerHTML=

"Login Successful";

window.location.href=

"profile.html";

}

}
function saveProfile(){

let name =
document.getElementById(
"name"
).value;

let skills =
document.getElementById(
"skills"
).value;

let domain =
document.getElementById(
"domain"
).value;

alert("Saved");

window.location.href=
"network.html";

}
function findTeam(){

document.getElementById(
"team").innerHTML=

`
<h3>
Recommended Team
</h3>

AI Engineer <br>

Frontend Developer <br>

Backend Developer <br>

Marketing Lead

`;

}
function postIdea(){

let idea =

document.getElementById(
"idea").value;

document.getElementById(
"output").innerHTML=

`

<h3>

Posted Startup Idea

</h3>

<p>

${idea}

</p>

`;

}
function postIdea(){

let idea =

document.getElementById(
"idea").value;

document.getElementById(
"output").innerHTML=

`

<h3>

Posted Startup Idea

</h3>

<p>

${idea}

</p>

`;

}
function findMentor(){

let domain =

document.getElementById(
"domain").value;

let mentor="";

if(domain=="AI"){

mentor=
"AI Research Mentor";

}

else if(
domain=="Healthcare"
){

mentor=
"Healthcare Startup Advisor";

}

else if(
domain=="Fintech"
){

mentor=
"Fintech Business Mentor";

}

else{

mentor=
"Education Innovation Mentor";

}

document.getElementById(
"mentorResult"
).innerHTML=

`

<h3>

Recommended Mentor

</h3>

<p>

${mentor}

</p>

`;

}
function generateIdea(){

let skills=

document.getElementById(
"skills").value;

let domain=

document.getElementById(
"domain").value;

document.getElementById(
"ideaOutput").innerHTML=

`

<h2>

Startup Idea

</h2>

<p>

AI based
${domain}

platform using

${skills}

</p>

<h3>

Problem

</h3>

Students lack startup support.

<h3>

Solution

</h3>

Provide AI driven collaboration.

<h3>

Revenue

</h3>

Subscriptions +
Premium mentorship

`;

}
const API_KEY =
AIzaSyB9gAN9E8_iZnRkfHnSc3IWRkTcqV1qW-g
function predictStartup(){

let team =

document.getElementById(
"team").value;

let experience =

document.getElementById(
"experience").value;

let fund =

document.getElementById(
"fund").value;

let score = 70;

if(team >= 4){

score +=10;

}

if(
experience.toLowerCase()
=="high"
){

score +=10;

}

if(fund >= 50000){

score +=10;

}

document.getElementById(
"prediction"
).innerHTML=

`

<h2>

Innovation Score

</h2>

<p>

Startup Success:

${score} %

</p>

`;

}